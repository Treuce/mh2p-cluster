# Audi Q7 (MH2p, P2711): Android Auto map in the Virtual Cockpit

Google Maps from Android Auto, full width in the Virtual Cockpit. It shows the 3D driving view with the turn card, and the car marker stays above Audi's bottom info bar. It works over a cable and through wireless Android Auto adapters.

**Download:** `ClusterIntegration_v0034_q7_p2711_audi.zip` from the [latest release](https://github.com/bhushangahire/mh2p-cluster/releases/latest), or from [`builds/`](../../builds/ClusterIntegration_v0034_q7_p2711_audi.zip) in this repo (open it and click the download button).

> Don't use GitHub's green **Code → Download ZIP** button. That downloads the project's source code, which the car can't install.

**Tested on:**
- Car: 2020 Audi Q7 (US) with the Virtual Cockpit.
- Head unit: MH2p, firmware `MH2P_US_AUG35_P2711`.
- Phone: Samsung Galaxy, Google Maps.
- Connections: USB cable, AAWireless (DPI 150), and another wireless adapter.

Other MH2p Audis with the same 1920×722 cockpit should be close but are untested. Experimental: install only while parked, and keep the backups the installer makes.

## Install

**Requirements:** Android Auto already working on the car, and the car parked. Read the main README's Audi section first.

The zip contains everything for one SD card:

| Folder | What it is |
|---|---|
| `Data/`, `Meta/` | LawPaul's MH2p SD ModKit v2 loader, unmodified. It lets the head unit install the mods. |
| `Mods/ClusterIntegration/` | This mod. |
| `Mods/NavCompassIgnore/` | LawPaul's NavCompassIgnore, unmodified. Without it the cockpit switches to the compass once navigation starts. If you already have it installed, installing it again is harmless. |

1. Format an SD card as **FAT32**. 32 GB or smaller is easiest; for larger cards, Windows can't format FAT32, so use Rufus or Raspberry Pi Imager.
2. Extract the zip, then copy what's **inside** it to the **root** of the card. When you open the card you must see `Data`, `Meta` and `Mods` immediately, not inside another folder. "Extract All" usually creates a folder named after the zip; copy its contents, not the folder.
3. On a Mac, remove the hidden `._` files macOS adds, or the update may not start: `dot_clean -m /Volumes/<card name>`.
4. Start the engine, then insert the card (lock switch unlocked). The head unit reboots and the update starts by itself within about 10 seconds. Don't touch the screen. It reboots several times, and red engineering pages may appear.
5. When asked to remove the update media, remove the card. The head unit restarts normally.
6. Copy `Mods/ClusterIntegration/Update/Backup/` from the card somewhere safe. The installer saves every file it replaced there.
7. Plug in the phone and start Google Maps navigation. The cockpit map should appear on the first connection.

If you use a wireless adapter with its own DPI setting, keep it moderate (150 worked). Some custom values made the phone drop the cockpit display.

**If the update doesn't start:**
- Nothing happens, or "update not supported": usually `Data`/`Meta` aren't at the card root, the card isn't FAT32, or macOS `._` files are present (steps 1–3).
- "BEM level is set to LEVEL 1": the engine isn't running.
- Error partway through: reformat the card or try another card.
- Check the head unit is MH2p: the MMI version should start with `MH2P_`.

**Uninstall:** put an empty `uninstall.txt` in `Mods/ClusterIntegration/` (and in `Mods/NavCompassIgnore/` to remove that too) and install the card again. ClusterIntegration restores the backed-up originals.

## Turning logs on (troubleshooting)

The zip writes no logs during normal use. To diagnose a problem, turn on what you need, re-run the ModKit install, and reproduce the problem. Turn it back off the same way afterwards.

| Log | How to turn it on | Where it goes |
|---|---|---|
| Installer | Always on | `Logs/ClusterIntegration.log` on the SD card, after each install |
| Java integration (session state, map hiding `KOMBI_MAP:`, turn events) | In `Mods/ClusterIntegration/config_overrides.txt`, change `enableExternalLogging=false` to `true` | `cluster.log` in the root of the USB stick in the car (it's always kept in RAM at `/tmp/cluster.log`) |
| Android Auto hook (service discovery, video channel) | Create `Mods/ClusterIntegration/gal_env.txt` with the two lines `GAL_CLUSTER_LOG=1` and `GAL_CLUSTER_LOG_ALL=1` (add `GAL_CLUSTER_SD_LOG=1` to also dump the service discovery) | RAM: `/tmp/gal_cluster.log`. Read it over SSH, or copy it to USB with `cp /tmp/*.log /fs/usb0_0/` |
| Cluster daemon (decoder, frame rate, `prepare`/`resume`/`stop` commands) | In both `Mods/ClusterIntegration/Persist/install.sh` and `Mods/ClusterIntegration/Update/gal`, add `verbose=2` after `daemon` on the line that starts the daemon (`... daemon verbose=2 >/dev/null 2>&1 &`) | `cluster_daemon.log` in the root of the first writable USB stick (falls back to `/tmp`), capped at 1 MB |

With SSH access (LawPaul's `mh2p-ssh-access` mod) you can turn on the daemon log for one session without reinstalling: stop the running daemon with `slay cluster`, then run `/mnt/app/eso/bin/apps/cluster/cluster daemon verbose=2 &`, then reconnect the phone. A reboot returns to normal.

Useful things to look for:
- `[daemon] polling` appears **once** per boot in `cluster_daemon.log`. Twice means two daemons are running.
- `decode_fps=` shows the video frame rate.
- `KOMBI_MAP: AA video rendering, hiding native cockpit map` in `cluster.log` confirms the native map was hidden.

## What this changes from upstream v0034 Audi

| Problem on the Q7 | Fix | Source |
|---|---|---|
| The native Audi cockpit map keeps drawing over the AA video (displayable 33). | `KombiMapGuard` suspends the native kombi map viewer while the AA video renders, and wakes it afterwards. | `lsd/.../nav/KombiMapGuard.java`, started from `AndroidAuto2Subsystem` |
| Black cockpit until a reconnect: the decoder started at the ring's current write position and skipped the session's SPS/PPS/IDR. | Decode from the ring start. | `src/cluster.c` |
| Map needed several reconnects: the gal wrapper and the Persist script each started a cluster daemon, and the two stole each other's commands. | Persist starts the daemon only when none is running. | `modkit/Mods/ClusterIntegration/Persist/install.sh` |
| Car marker hidden under Audi's bottom bar, turn card clipped by the curved edge. The hook sends a fixed 54-byte cluster template (`dhu_cluster_service[]`), so `GAL_CLUSTER_INSET_*` never reaches the phone. | Template rewritten in place for the Q7 cockpit (below). | `gal_cluster.so` at file offset `0x7384` |
| Settings | `codecRes=1080`, `mode="fill"`, `panY=0.0`, Java log to USB off. | `Mods/ClusterIntegration/config_overrides.txt` in the zip |
| Every user got a `cluster_daemon.log` on their USB stick: both places that start the daemon passed `verbose=2`. | Start the daemon without `verbose`; nothing is written to USB. | `Persist/install.sh`, `modkit/Mods/ClusterIntegration/Update/gal` |

**Cockpit template values:**
- `display_type`: CLUSTER (3D driving view; AUXILIARY gives a flat 2D map).
- Stream: 1080p.
- `height_margin`: 358. The daemon's `fill` crop shows rows 179–900, which is exactly the active area.
- UI margins: top 179, bottom 180.
- Content insets: bottom 195 (Audi's info bar), left and right 160 (curved edges).
- Density: 200.

The template bytes:

```
0a34080e1a30222a 0801 1001 20e602 28c801 38f403 40904e 48c801 5003
5a13 0a06 08b301 10b401 1209 10c301 18a001 20a001 3001 3801
```

The `cluster` daemon in the zip is upstream's build with the `src/cluster.c` change applied as two instructions (file offset `0x66ec`: `mov.w r11,#0`, `mov.w r4,#0`). The jar is upstream's Android-Auto-only jar rebuilt with `KombiMapGuard` (ECJ, `-source 1.5 -target jsr14`).

## Known limits

- **HUD:** no arrows or distance on the head-up display, only the street name. With the cockpit coded for the map (`navMapTransmissionMode=3`), the head unit drops the BAP arrow data.
- **Center screen:** while the cockpit map is active, it shows Google's route overview. That's Google's design for cars with a cluster display.
- **Frame rate:** about 10–15 fps while the map rotates. The phone's encoder limits this; the head unit decodes every frame.
- **Native map:** the Audi navigation map is hidden while Android Auto video runs in the cockpit, and comes back when AA disconnects.

## Credits

- **fifthBro:** the original MH2p cluster integration (hook, daemon, Java integration). https://fifthbro.github.io
- **jonny190/mh2p-cluster:** the Audi package this builds on, with Jonathan Davey and jakublamik. https://github.com/jonny190/mh2p-cluster
- **LawPaul:** MH2p SD ModKit (the zip's `Data/` and `Meta/` are his signed ModKit v2, unmodified) and NavCompassIgnore (`Mods/NavCompassIgnore/`, unmodified from [LawPaul/MH2p_NavCompassIgnore](https://github.com/LawPaul/MH2p_NavCompassIgnore) at `1dc404c`), both CC BY-NC-SA 4.0; also SSH access. https://lawpaul.github.io/MH2p_SD_ModKit_Site/
- **luka-dev:** mib2q-carplay-rgi, navigation event research used upstream. https://github.com/luka-dev/mib2q-carplay-rgi
- **Q7 P2711 fixes and profile:** Bhushan Ahire.

## License

Same as the rest of this repository: [CC BY-NC-SA 4.0](../../LICENSE.md). Non-commercial use only. Changes from upstream are listed above.

The zip contains no Audi, Harman or Google files. The ModKit loader and NavCompassIgnore in it are LawPaul's work, included unmodified under their CC BY-NC-SA 4.0 license. Not affiliated with or endorsed by Audi, Volkswagen Group, Harman or Google. "Audi", "Android Auto" and "Google Maps" are trademarks of their owners and are used only to describe compatibility. Use at your own risk; modifying the head unit may affect your warranty.
